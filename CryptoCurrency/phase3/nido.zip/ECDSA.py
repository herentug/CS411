import random
from Crypto.Hash import SHA3_256
from ecpy.curves import Curve,Point

def egcd(a, b):
    x,y, u,v = 0,1, 1,0
    while a != 0:
        q, r = b//a, b%a
        m, n = x-u*q, y-v*q
        b,a, x,y, u,v = a,r, u,v, m,n
    gcd = b
    return gcd, x, y

def modinv(a, m):
    if a < 0:
        a = a+m
    gcd, x, y = egcd(a, m)
    if gcd != 1:
        return None  # modular inverse does not exist
    else:
        return x % m


def KeyGen(E):
	n=E.order
	P=E.generator
	sA=random.randint(1,n-1)
	QA=P*sA
	return sA, QA
"""
h_obj = SHA3_256.new()
	h_obj.update(message)
	h = h_obj.hexdigest()
"""
def SignVer(message,s,r,E,QA):
	n=E.order
	P=E.generator

	h_obj = SHA3_256.new()
	h_obj.update(message)
	h = h_obj.hexdigest()
	h=int(h, 16)
	sInv=modinv(s,n)
	u1=(sInv*h)%n
	u2=(sInv*r)%n
	V=(u1*P) + (u2*QA)
	v=(V.x)%n

	if((v%n)==(r%n)):
		return 0
	else:
		return 1


def SignGen(message, E, sA):
	n=E.order
	P=E.generator

	h_obj = SHA3_256.new()
	h_obj.update(message)
	h = h_obj.hexdigest()
	h=int(h, 16)

	k=random.randrange(1,n)
	R=k*P
	r=(R.x) %n
	s=(modinv(k,n)*(h+sA*r))%n
	return	s,r
